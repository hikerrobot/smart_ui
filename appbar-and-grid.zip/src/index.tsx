import React from "react";
import ReactDOM from "react-dom";
import Demo from "./demo";
import App from "./app";

// ReactDOM.render(<Demo />, document.querySelector('#root'));
ReactDOM.render(<App />, document.querySelector("#root"));
