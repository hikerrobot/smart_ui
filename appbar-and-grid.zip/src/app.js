import React from "react";

import ButtonAppBar from "./ButtonAppBar";
import Demo from "./demo";

export default function App() {
  return (
    <div>
      <ButtonAppBar />
      <header>
        <Demo />
      </header>
    </div>
  );
}
